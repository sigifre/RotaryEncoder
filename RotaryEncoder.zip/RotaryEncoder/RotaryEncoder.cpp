#include "RotaryEncoder.h"

RotaryEncoder::RotaryEncoder(
    uint8_t EncoderCLK, 
    uint8_t EncoderDT, 
      float Steps,
      float Mincounter,
      float Maxcounter
    )
{
  _EncoderCLK = EncoderCLK;
  _EncoderDT  = EncoderDT;
       _Steps = Steps;
  _Mincounter = Mincounter;
  _Maxcounter = Maxcounter;
}

void RotaryEncoder::begin(float position){
  pinMode(_EncoderCLK, INPUT_PULLUP);
  pinMode(_EncoderDT,  INPUT_PULLUP);
  readAB();
  _counter = position;
}

void RotaryEncoder::readAB(){
	New = false;
_currValueCLK = digitalRead(_EncoderCLK);
_currValueDT  = digitalRead(_EncoderDT);

if (_prevValueCLK != _currValueCLK){
	if (_currValueDT == _currValueCLK) {
	_counter = _counter + _Steps; New = true;
	if (_counter > _Maxcounter) {_counter = _Maxcounter; New = false;}
	}
else {
  _counter = _counter - _Steps; New = true;
	if (_counter < _Mincounter) {_counter = _Mincounter; New = false;}
}

if (_counterLast != _counter){_counterLast = _counter;}
_prevValueCLK = _currValueCLK;
}
}

uint8_t RotaryEncoder::AnyNew(){
readAB();
return New;
}

float RotaryEncoder::getPosition(){return _counter;}

void RotaryEncoder::setPosition(float position){_counter = position;}
	
void RotaryEncoder::Relocate(){//useful when using multiple encoders on the same single hardware (menus etc)
float LAST=getPosition();
readAB();
New = true;
setPosition(LAST);
	}