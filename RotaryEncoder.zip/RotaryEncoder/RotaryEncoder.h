/***************************************************************************************************/
#ifndef RotaryEncoder_h
#define RotaryEncoder_h

#if defined(ARDUINO) && ((ARDUINO) >= 100) //arduino core v1.0 or later
#include <Arduino.h>
#else
#include <WProgram.h>
#endif

#if defined(__AVR__)
#include <avr/pgmspace.h>                  //use for PROGMEM Arduino AVR
#elif defined(ESP8266)
#include <pgmspace.h>                      //use for PROGMEM Arduino ESP8266
#elif defined(_VARIANT_ARDUINO_STM32_)
#include <avr/pgmspace.h>                  //use for PROGMEM Arduino STM32
#endif

class RotaryEncoder{
  public:
    RotaryEncoder(
    uint8_t EncoderCLK, 
    uint8_t EncoderDT, 
      float Steps,
      float Mincounter,
      float Maxcounter
         
    );

    void    begin(float position);//float position
    void    readAB(void);
   float    getPosition(void);
    void    setPosition(float position);
    void    Relocate(void);
 uint8_t    AnyNew();
  

  private:
             uint8_t _EncoderCLK;     //pin "A"
             uint8_t _EncoderDT;      //pin "B"
               float _Steps;
               float _Mincounter;
               float _Maxcounter;
             uint8_t New;

volatile uint8_t _currValueCLK = 0;
volatile uint8_t _currValueDT = 0;

volatile uint8_t _prevValueCLK = 0;
volatile uint8_t _prevValueDT = 0;

protected:
float _counter     = 0.0;
float _counterLast = 0.0;
};

#endif
